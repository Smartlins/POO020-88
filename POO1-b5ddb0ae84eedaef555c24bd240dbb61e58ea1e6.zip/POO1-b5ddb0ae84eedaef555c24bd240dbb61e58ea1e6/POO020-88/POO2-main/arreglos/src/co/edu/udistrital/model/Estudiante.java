package co.edu.udistrital.model;

public class Estudiante {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
